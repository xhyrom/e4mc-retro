package link.e4mc;

import net.minecraftforge.fml.common.Mod;

@Mod(modid = E4mcClient.MOD_ID, useMetadata = true, acceptableRemoteVersions = "*")
public class E4mcClientForge {
    public E4mcClientForge() {}
}
