plugins {
    idea
    id("fabric-loom") version "1.8-SNAPSHOT"
    id("legacy-looming") version "1.8-SNAPSHOT"
}

group = "dev.xhyrom.e4mc"
version = "1.0.0+1.12.2"

val minecraftVersion: String = property("minecraft_version") as String
val yarnBuild: String = property("yarn_build") as String
val loaderVersion: String = property("fabric_loader_version") as String
val fabricVersion: String = property("fabric_version") as String

loom {}
legacyLooming {}

dependencies {
    minecraft("com.mojang:minecraft:${minecraftVersion}")
    mappings(legacy.yarn(minecraftVersion, yarnBuild))
    modImplementation("net.fabricmc:fabric-loader:${loaderVersion}")

    // Legacy Fabric API provides hooks for events, item registration, and more. As most mods will need this, it's included by default.
    // If you know for a fact you don't, it's not required and can be safely removed.
    // As of September 2024, available for MC 1.6.4, 1.7.10, 1.8, 1.8.9, 1.9.4, 1.10.2, 1.11.2 and 1.12.2.
    // As of September 2024, available only for intermediary generation 1.
    modImplementation("net.legacyfabric.legacy-fabric-api:legacy-fabric-api:${fabricVersion}")

    // You can retrieve a specific api module using this notation.
    // modImplementation(legacy.apiModule("legacy-fabric-item-groups-v1", project.fabric_version))
    implementation(project(":common"))
}