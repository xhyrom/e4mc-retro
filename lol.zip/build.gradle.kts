plugins {
    id("java")
    id("idea")
    id("com.github.johnrengelman.shadow") version "8.1.1"
}

val archivesBaseName: String = property("archives_base_name") as String
val modId: String = property("mod_id") as String
val modVersion: String = property("mod_version") as String
val mavenGroup: String = property("maven_group") as String

base.archivesName = archivesBaseName
version = modVersion
group = mavenGroup

subprojects {
    apply(plugin = "java")
    apply(plugin = "com.github.johnrengelman.shadow")

    repositories {
        mavenCentral()
        maven("https://repo.spongepowered.org/maven/")
        maven("https://repo.sleeping.town/")
        maven("https://raw.githubusercontent.com/BleachDev/cursed-mappings/main/")
    }

    tasks.processResources {
        inputs.property("version", project.version)
        inputs.property("mod_id", modId)

        filesMatching(listOf("mcmod.info", "fabric.mod.json", "mixins.${modId}.json")) {
            expand(inputs.properties)
        }
    }

    tasks.build {
        dependsOn(tasks.shadowJar)
    }

    tasks.shadowJar {
        archiveClassifier = "lol"
        doLast {
            configurations.forEach {
                println("Copying dependencies into mod: ${it.files}")
            }
        }

        exclude("META-INF/maven/**")
        exclude("META-INF/native-image/**")
        exclude("META-INF/io.netty.versions*")
        exclude("META-INF/services/reactor*")

        relocate("com.electronwill.nightconfig", "link.e4mc.shadow.nightconfig")
        relocate("folk.sisby.kaleido", "link.e4mc.shadow.kaleido")
    }

    tasks.withType(JavaCompile::class) {
        options.encoding = "UTF-8"
    }

    java {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8

        toolchain.languageVersion = JavaLanguageVersion.of(8)
    }
}